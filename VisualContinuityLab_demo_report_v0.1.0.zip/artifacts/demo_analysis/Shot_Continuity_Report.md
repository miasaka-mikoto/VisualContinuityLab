# Shot Continuity Report

- **Identity Stability**: 98.78/100
- **Motion Stability**: 95.64/100
- **Color Stability**: 98.52/100
- **Lighting Stability**: 96.96/100
- **Background Stability**: 98.12/100
- **Overall**: 97.60/100

## Bad Frames

7 (High), 8 (High), 10 (High), 11 (High), 12 (High), 13 (High), 14 (High), 15 (High), 16 (High), 17 (High), 18 (High), 19 (High), 20 (Medium), 22 (Medium), 23 (Medium)

## Recommended Frames to Regenerate

7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 22, 23

## Issues

- **High** `color_drift` — frames 7 → 8: Costume colour drift
- **High** `color_drift` — frames 10 → 11: Costume colour drift
- **High** `body_proportion_drift` — frames 12 → 13: Body proportion changed
- **High** `character_position_drift` — frames 12 → 13: Character position jump
- **High** `character_scale_jump` — frames 12 → 13: Character scale jump
- **High** `body_proportion_drift` — frames 13 → 14: Body proportion changed
- **High** `character_position_drift` — frames 13 → 14: Character position jump
- **High** `character_scale_jump` — frames 13 → 14: Character scale jump
- **High** `brightness_flicker` — frames 15 → 16: Brightness flicker
- **High** `brightness_flicker` — frames 16 → 17: Brightness flicker
- **High** `brightness_flicker` — frames 17 → 18: Brightness flicker
- **High** `brightness_flicker` — frames 18 → 19: Brightness flicker
- **Medium** `background_drift` — frames 19 → 20: Background changed
- **Medium** `background_drift` — frames 22 → 23: Background changed
